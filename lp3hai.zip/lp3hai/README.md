# LP3 – Practical Codes
- BCT/ : Bank.sol, StudentData.sol (Solidity, paste into Remix)
- DAA/ : fibonacci, huffman_encoding, fractional_knapsack, knapsack_01, nqueens (.py)
- ML/  : 5 Jupyter notebooks (Kaggle dataset paths – change to your local/Colab path)
